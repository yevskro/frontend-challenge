/* action types */
export const SET_DATA = 'SET_DATA';
export const ADD_FILTER = 'ADD_FILTER';
export const REMOVE_FILTER = 'REMOVE_FILTER';
export const CLEAR_FILTERS = 'CLEAR_FILTERS';
export const FILTER_DATA = 'FILTER_DATA';
